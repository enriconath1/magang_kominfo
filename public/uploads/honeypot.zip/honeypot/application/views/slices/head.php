<!-- robot speak -->	
<meta charset="utf-8">
<title><?php if (!empty($title)) echo $title . ' | '; ?></title>
<?php echo chrome_frame(); ?>
<?php echo view_port(); ?>
<?php echo apple_mobile('black-translucent'); ?>
<?php echo $meta; ?>

<!-- icons and icons and icons and icons and icons and a tile -->
<?php echo windows_tile(array('name' => 'Stencil', 'image' => base_url() . '/assets/img/icons/tile.png', 'color' => '#4eb4e5')); ?>
<?php echo favicons(); ?>

<!-- crayons and paint -->	
<?php echo add_css(array('bootstrap', 'style', 'style-responsive', 'font-awesome','flaty_modified','jquery-jvectormap-1.2.2')); ?>
<?php echo $css; ?>

<!-- magical wizardry -->
<?php echo jquery('1.9.1'); ?>
<?php echo shiv(); ?>
<?php echo add_js(array('bootstrap.min', 'scripts')); ?>
<?php echo $js; ?>

<style type="text/css">
    .header-image{
        content:url(http://202.43.191.139:8010/hpot3/images/banner.png);
        max-width: 100%;
    }
    .jvectormap-region {
        stroke: #005826;
        stroke-width: 0.5;
    }
</style>

<script type="text/javascript">
    $(document).ready(function() {
        // Handler for .ready() called.
        $("#<?php echo $active_nav; ?>").addClass("active");
    });
</script>