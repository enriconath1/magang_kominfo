<!DOCTYPE html>
<!--[if lt IE 7 ]> <html class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html> <!--<![endif]-->
    <head>
        <?php echo $head; ?>
    </head>
    <body>
        <div id="configurator">
            <a class="control" href="#">Show / Hide</a>
            <div class="inside">
                <div class="header">Choose Month</div>
                <fieldset>
                    <form class="form-horizontal" role="form">
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Year</label>
                            <div class="col-sm-7">
                                <select class="form-control year-filter">
                                    <?php
                                    
                                    foreach($filter as $fl){
                                        echo '<option value="'.$fl.'">'.$fl.'</option>';
                                    }
                                    
                                    ?>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Month</label>
                            <div class="col-sm-7">
                                <select class="form-control month-filter">
                                    
                                </select>
                            </div>
                        </div>
                        <hr />
                        <div class="form-group">
                            <a class="btn btn-primary btn-sm middle" id="submit-filter">Submit</a>
                        </div>
                    </form>
                </fieldset>

            </div>

        </div>   


        <header>
<?php echo $header; ?>
        </header>

        <div>
<?php echo $content; ?>
        </div>

        <hr>

        <footer class="col12 colloumn">
            <div class="col8 colloumn">
            <p>&copy; Menkominfo 2014</p>
            </div>
            <div class="col4 colloumn" ">
                <!--<a href="gsk.co.id" rel="follow"><p>Powered By Garuda Solusi Kreatif</p></a>-->
            </div>
        </footer>

    </body>
</html>
