<input type="hidden" class="page-type" value="summary" />

<div class="starter-template">
    <div class="col8 colloumn box shadow">
        <legend>Sum of attacks per Day in a Month <span>(Total)</span></legend>
        <div id="dailyAttack" class="center"></div>
    </div>


    <div class="col4 colloumn box shadow">
        <legend>List of Attacker Country <span></span></legend>

        <div id="change" class='attacker-list-by-country'>
            <table class="table table-condensed" id="sumAtt">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Source of Attack</th>
                        <th>Attack</th>                                      
                    </tr>
                </thead>   
                <tbody>                  
                </tbody>
            </table>
        </div> 
    </div>

    <div class="col8 colloumn box shadow">
        <legend>Average of attacks per Hour in a Month <span>(Total)</span></legend>
        <div id="hour" class="center"></div>
    </div>


    <div class="col4 colloumn box shadow">
        <legend>List of Attacked Port <span></span></legend>

        <div id="change" class='attacker-list-by-country'>
            <table class="table table-condensed" id="topPort">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Number of Attack</th>                                      
                    </tr>
                </thead>   
                <tbody>                  
                </tbody>
            </table>
        </div>
    </div> 
</div>

</div>