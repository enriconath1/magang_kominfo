<input type="hidden" class="page-type" value="maps" />
<div class="starter-template">
    <div class="col8 colloumn box shadow">
        <legend>Indonesian Honeymap <span></span></legend>
        <div id="map"></div>
        <div id="key" style="height: 50px"></div>
    </div>


    <div class="col4 colloumn box shadow">
        <legend>Top 5 Attacker by Country <span></span></legend>
        <div id="piechartCountry"></div>
        <div id="hover"></div>
    </div>

    <div class="col8 colloumn box shadow">
        <legend>Live Ticker From 8 Sensors</legend>
        <div style='height:400px;overflow:auto;'>
            <table class="table table-condensed" id="live"> 
                <thead>
                <th>Date</th>
                <th>Source</th>
                <th>Target</th>
                <th>Attack On</th>
                <th>Parameter</th>
                </thead>
                <tbody>                  
                </tbody>
            </table>
        </div>
    </div>

    <div class="col4 colloumn box shadow">
        <legend>List of Attacker by Country</legend>
        
        <div class="attacker-list-by-country">
            <table class="table table-condensed" id="sumAtt">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Source of Attack</th>
                        <th>Number of Attack</th>                                         
                    </tr>
                </thead>   
                <tbody>                  
                </tbody>
            </table>
        </div> 

    </div>
    
    

</div>