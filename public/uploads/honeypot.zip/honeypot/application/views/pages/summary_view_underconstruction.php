<div class="col12 under-construction shadow">

    <h2>Well This is Embarrassing, But This Page is Still Under Construction.</h2>
    <h5>We're Still Work On It, Please Be Patient</h5>
    <a href="gsk.co.id">
        <div class="image-wrapper">
            <?php echo img('assets/img/infrastructure.png'); ?>
        </div>
    </a>

</div>