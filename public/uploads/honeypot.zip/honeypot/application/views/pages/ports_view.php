<input type="hidden" class="page-type" value="ports" />
<div class="starter-template">
    <div class="col8 colloumn box shadow ports-box">
        <legend>Attacked Port <span></span></legend>
        <label>
<!--            <select id="piebar">
                <option value="bar" selected="">Bar Chart</option>
                <option value="pie">Pie Chart</option>
            </select>-->
        </label>

        <div id="portCharts" style="height:380px"></div>
        <div id="portHover"></div>
    </div>


    <div class="col4 colloumn box shadow ports-box">
        <legend>List of Attacked Port <span></span></legend>
        <div class='top-port-list'>
            <table class="table table-condensed" id="topPort">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Number of Attack</th>                                      
                    </tr>
                </thead>   
                <tbody>                  
                </tbody>
            </table>
        </div> 
    </div>

</div>