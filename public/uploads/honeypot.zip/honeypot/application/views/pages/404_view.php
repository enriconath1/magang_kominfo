<h1><?php echo $subpage_text; ?></h1>

<p>Page Not Found</p>