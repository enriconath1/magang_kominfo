<?php

class Statistic_c extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        echo "asdasda";
    }

    function queryPort5() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(local_port) as a, local_port as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by local_port order by a desc limit 5";

        $string_result = $this->c2database_m->queryDual($sql);
        echo $string_result;
    }

    function queryPort() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(local_port) as a, local_port as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by local_port order by a desc";

        $string_result = $this->c2database_m->queryDual($sql);
        echo $string_result;
    }

    function queryPortName() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(connection_protocol) as a, connection_protocol as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by connection_protocol order by a desc";

        $string_result = $this->c2database_m->queryDual($sql);
        echo $string_result;
    }

    function queryPortName5() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(connection_protocol) as a, connection_protocol as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by connection_protocol order by a desc limit 5";

        $string_result = $this->c2database_m->queryDual($sql);
        echo $string_result;
    }

    function queryAttacker5() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT COUNT(country_name) as a,country_name as b FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and connection_type = 'accept' GROUP BY country_name ORDER BY COUNT(country_name) DESC limit 5";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    function queryAttacker5New($decrement) {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT COUNT(country_name) as a,country_name as b FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and date_part('month',connection_timestamp) = (date_part('month',current_date)" . $decrement . ") and connection_type = 'accept' GROUP BY country_name ORDER BY COUNT(country_name) DESC limit 5";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    function queryAttacker() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT COUNT(country_name) as a,country_name as b FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and connection_type = 'accept' GROUP BY country_name ORDER BY COUNT(country_name) DESC";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    function queryAttackerNew($decrement) {

        $this->load->model('c2database_m', '', TRUE);
        //$sql = "SELECT COUNT(country_name) as a,country_name as b, country_short as c FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and date_part('month',connection_timestamp) = (date_part('month',current_date)".$decrement.") and connection_type = 'accept' GROUP BY country_name,country_short ORDER BY COUNT(country_name) DESC";
        $sql = "SELECT COUNT(country_name) as a,country_name as b, country_short as c FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and connection_type = 'accept' GROUP BY country_name,country_short ORDER BY COUNT(country_name) DESC";

        $string_result = $this->c2database_m->queryABC($sql);
        echo $string_result;
    }

    function queryTopAttacker() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT COUNT(country_name) as b, country_short as a FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='' and country_short!='A1' and country_short!='none') and connection_type = 'accept' GROUP BY country_short ORDER BY COUNT(country_name) DESC";

        $string_result = $this->c2database_m->queryMap($sql);
        echo $string_result;
    }

    function queryMalware5() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(virustotalscan_result) as a, virustotalscan_result as b from dionaea.virustotalscans, dionaea.virustotals where virustotalscan_scanner='McAfee' and virustotalscans.virustotal = virustotals.virustotal and date_part('month',virustotal_timestamp) = (date_part('month',current_date)-1) and date_part('year',virustotal_timestamp) = date_part('year',current_date) GROUP BY B ORDER BY A DESC limit 5";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    function queryMalware() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "select count(virustotalscan_result) as a, virustotalscan_result as b from dionaea.virustotalscans, dionaea.virustotals where virustotalscan_scanner='McAfee' and virustotalscans.virustotal = virustotals.virustotal and date_part('month',virustotal_timestamp) = (date_part('month',current_date)-1) and date_part('year',virustotal_timestamp) = date_part('year',current_date) GROUP BY B ORDER BY A DESC";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    function queryDaily() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT date(connection_timestamp) as a, COUNT(*)as b, date_part('epoch',date(connection_timestamp)) as c FROM dionaea.connections WHERE connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) and date_part('year',connection_timestamp) = date_part('year',current_date) GROUP BY date(connection_timestamp) ORDER BY A";

        $string_result = $this->c2database_m->queryAB2($sql);
        echo $string_result;
    }

    function queryTime() {

        $this->load->model('c2database_m', '', TRUE);
        $sql = "SELECT date_part('hour',connection_timestamp) AS a, COUNT(*) as b FROM dionaea.connections WHERE connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) GROUP BY a ORDER BY A DESC";

        $string_result = $this->c2database_m->queryAB($sql);
        echo $string_result;
    }

    // COBA!!!
    /* function queryLive(){

      $this->load->model('c2database_m', '', TRUE);
      $sql = "SELECT to_char(connection_timestamp, 'HH24:MI:SS') as a, country_short as b, local_port as c FROM dionaea.connections WHERE connection_type='accept' AND (country_name!='UNKNOWN' and country_name!='-' and country_name!='' and country_short!='A1' and country_short!='none') AND to_char(connection_timestamp, 'YYYY-MM-DD') >= '".date("Y-m-d")."' ORDER BY connection_timestamp DESC";

      $string_result = $this->c2database_m->queryABC($sql);
      echo $string_result;
      } */
    function queryLive() {

        $this->load->model('c2database_m', '', TRUE);
//             $statictime = 15:10:00;
        // echo "<script type='text/javascript'>alert('$statictime');</script>";

        $time = date("H:i:s");
        $date = new DateTime($time);
        $date->sub(new DateInterval('P0DT1H2M10S'));

        $date2 = new DateTime($time);
        $date2->sub(new DateInterval('P0DT1H2M11S'));

        //$date = date("H:i:s");
        //$time = strtotime($date);
        //$time = $time - (60 * 60);
        //$date = date("H:i:s", $time);


        $sql = "SELECT to_char(connection_timestamp, 'HH24:MI:SS') as a, country_name as b, local_port as c FROM dionaea.connections 
			WHERE connection_type='accept' AND (country_name!='UNKNOWN' AND country_name!='-' AND country_name!='' 
			AND country_short!='A1' AND country_short!='none') AND to_char(connection_timestamp, 'YYYY-MM-DD') >= '" . date("Y-m-d") . "' 
			AND to_char(connection_timestamp, 'HH24:MI:SS') between '" . $date2->format('H:i:s') . "' and '" . $date->format('H:i:s') . "' ORDER BY connection_timestamp ASC";

        $string_result = $this->c2database_m->queryABC($sql);
        echo $string_result;
    }

}
