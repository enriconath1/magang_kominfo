<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //Sets the variable $head to use the slice head (/views/slices/head.php)
        $this->stencil->slice('head');
        $this->stencil->layout('home_layout');
        $this->stencil->slice('header');
        $this->stencil->title('Indonesia Network Monitor | Maps');
        $this->stencil->js('jquery-jvectormap-1.2.2.min');
        $this->stencil->js('jquery-jvectormap-world-mill-en');
        $this->stencil->js('excanvas');
        $this->stencil->js('jquery.flot.min');
        $this->stencil->js('jquery.flot.pie.min');
        $this->stencil->js('jquery.flot.stack');
        $this->stencil->js('jquery.flot.resize.min');
        $this->stencil->js('honeymap');
        $this->load->model('data_sum');
    }

    public function index() {

        //$sensor = $this->data->query("SELECT COUNT(sensor_id) as a FROM users.sensor");
        $data = array(
            'title' => 'Indonesia Network Monitor | Maps',
            'active_nav' => 'home_nav',
            'filter' => $this->data_sum->queryTimeAll(),
        );
        $this->stencil->paint('home_view', $data);
    }

    public function ports() {
        $sql = "SELECT COUNT(attack_count) as a, port_name as b FROM port GROUP BY port_name ORDER BY COUNT(attack_count) LIMIT 10";
        $string_result = $this->data_sum->queryDual($sql);
        $data = array(
            'title' => 'Indonesia Network Monitor | Attacked Port',
            'active_nav' => 'statistics_nav',
            'filter' => $this->data_sum->queryTimeAll()
        );

        $this->stencil->paint('ports_view', $data);
    }

    public function malware() {
        $sql = "SELECT COUNT(DISTINCT(malware_name)) as a FROM malware";
        $string_result = $this->data_sum->query($sql);
        $data = array(
            'title' => 'Indonesia Network Monitor | Malware',
            'active_nav' => 'malware_nav',
            'filter' => $this->data_sum->queryTimeAll(),
            'uniqueMalware' => $string_result
        );


        $this->stencil->paint('malware_view', $data);
    }

    public function summary() {
        $data = array(
            'title' => 'Indonesia Network Monitor | Summary',
            'active_nav' => 'summary_nav',
            'filter' => $this->data_sum->queryTimeAll()
        );


        $this->stencil->paint('summary_view', $data);
    }

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */