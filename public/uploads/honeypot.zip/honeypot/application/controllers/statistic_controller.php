<?php

class Statistic_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('data_sum', '', TRUE);
    }

    function queryPort5() {

        $sql = "select count(local_port) as a, local_port as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by local_port order by a desc limit 5";
        $string_result = $this->data_sum->queryDual($sql);
        echo $string_result;
    }

    function queryPort() {
        $sql = "select count(local_port) as a, local_port as b from dionaea.connections where connection_type='accept' and date_part('month',connection_timestamp) = (date_part('month',current_date)-1) group by local_port order by a desc";
        $string_result = $this->data_sum->queryDual($sql);
        echo $string_result;
    }

    function queryPortName() {

        $sql = "SELECT attack_count as a, port_name as b FROM port GROUP BY port_name ORDER BY attack_count DESC";
        $string_result = $this->data_sum->queryDual($sql);
        echo $string_result;
    }

    function queryPortName5() {

        $sql = "SELECT attack_count as a, port_name as b FROM port GROUP BY port_name ORDER BY attack_count DESC LIMIT 5";
        $string_result = $this->data_sum->queryDual($sql);
        echo $string_result;
    }

    function queryAttacker5() {

        $sql = "SELECT SUM(attack_count) as a,country_name as b, country_code as c FROM country WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') GROUP BY country_code ORDER BY SUM(attack_count) DESC limit 5";
        $string_result = $this->data_sum->query1($sql);
        echo $string_result;
    }

    function queryAttackerAll() {

        $sql = "SELECT SUM(attack_count) as a,country_name as b, country_code as c FROM country WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') GROUP BY country_code ORDER BY SUM(attack_count) DESC";
        $string_result = $this->data_sum->query1($sql);
        echo $string_result;
    }

    function queryAttacker5New($decrement) {

        $sql = "SELECT SUM(attack_count) as a,country_name as b FROM country WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and date_part('month',connection_timestamp) = (date_part('month',current_date)" . $decrement . ") and connection_type = 'accept' GROUP BY country_name ORDER BY COUNT(country_name) DESC limit 5";
        $string_result = $this->data_sum->query1($sql);
        echo $string_result;
    }

    function queryAttacker() {

        $sql = "SELECT COUNT(country_name) as a,country_name as b FROM dionaea.connections WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and connection_type = 'accept' GROUP BY country_name ORDER BY COUNT(country_name) DESC";
        $string_result = $this->data_sum->query1($sql);
        echo $string_result;
    }

    function queryAttackerNew($decrement) {

        $sql = "SELECT SUM(attack_count) as a, country_code as b, country_short as c FROM country WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') and connection_type = 'accept' GROUP BY country_name,country_short ORDER BY COUNT(country_name) DESC";
        $string_result = $this->data_sum->query2($sql);
        echo $string_result;
    }

    function queryTopAttacker() {

        $sql = "SELECT SUM(attack_count) as a,country_code as b FROM country WHERE (country_name!='UNKNOWN' and country_name!='-' and country_name!='') GROUP BY country_code ORDER BY SUM(attack_count)";
        $string_result = $this->data_sum->query3($sql);
        echo $string_result;
    }

    function queryMalware5() {

        $sql = "SELECT attack_count as a, malware_name  as b FROM malware GROUP BY malware_name ORDER BY attack_count DESC limit 5";
        $string_result = $this->data_sum->query5($sql);
        echo $string_result;
    }

    function queryMalware() {

        $sql = "SELECT attack_count as a, malware_name  as b FROM malware GROUP BY malware_name ORDER BY attack_count DESC";
        $string_result = $this->data_sum->query5($sql);
        echo $string_result;
    }

    function queryDaily() {

        $sql = "SELECT SUM(attack_count) as b, DAY(summary_day_date) as a FROM summary_day GROUP BY DAY(summary_day_date) ORDER BY DAY(summary_day_date) ASC";
        $string_result = $this->data_sum->query4($sql);
        echo $string_result;
    }

    function queryTime() {

        $sql = "SELECT SUM(attack_count) as b, summary_hour as a FROM summary_hour GROUP BY summary_hour ORDER BY summary_hour ASC";
        $string_result = $this->data_sum->query5($sql);
        echo $string_result;
    }

    function queryLive() {

        $time = date("H:i:s");
        $date = new DateTime($time);
        $date->sub(new DateInterval('P0DT1H2M10S'));

        $date2 = new DateTime($time);
        $date2->sub(new DateInterval('P0DT1H2M11S'));

        $sql = "SELECT to_char(connection_timestamp, 'HH24:MI:SS') as a, country_name as b, local_port as c FROM dionaea.connections 
			WHERE connection_type='accept' AND (country_name!='UNKNOWN' AND country_name!='-' AND country_name!='' 
			AND country_short!='A1' AND country_short!='none') AND to_char(connection_timestamp, 'YYYY-MM-DD') >= '" . date("Y-m-d") . "' 
			AND to_char(connection_timestamp, 'HH24:MI:SS') between '" . $date2->format('H:i:s') . "' and '" . $date->format('H:i:s') . "' ORDER BY connection_timestamp ASC";

        $string_result = $this->data_sum->query2($sql);
        echo $string_result;
    }

    function getDataByTime() {
        $year = $_GET['year'];
        $month = $_GET['month'];
        $flag = $_GET['all'];
        $pageType = $_GET['pageType'];


        $sqlTime = $this->data_sum->queryTime($month, $year);
        foreach ($sqlTime as $time) {
            $timeID = $time;
        }

        if ($pageType == "maps") {
            if ($flag == '1') {
                $sql = "SELECT SUM(attack_count) as a,country_name as b,country_code as c FROM country WHERE time_id='" . $timeID . "' GROUP BY b ORDER BY a DESC";
            } else {
                $sql = "SELECT SUM(attack_count) as a,country_name as b,country_code as c FROM country WHERE time_id='" . $timeID . "' GROUP BY b ORDER BY a DESC LIMIT 5";
            }
            $string_result = $this->data_sum->query1($sql);
        } else if ($pageType == "ports") {
            $sql = "SELECT attack_count as a, port_name as b FROM port WHERE time_id = " . $timeID . " GROUP BY port_name ORDER BY attack_count DESC";
            $string_result = $this->data_sum->queryDual($sql);
        } else if ($pageType == "malware") {
            if ($flag == '1') {
                $sql = "SELECT attack_count as a, malware_name  as b FROM malware WHERE time_id = " . $timeID . " GROUP BY malware_name ORDER BY attack_count DESC";
            } else {
                $sql = "SELECT attack_count as a, malware_name  as b FROM malware WHERE time_id = " . $timeID . " GROUP BY malware_name ORDER BY attack_count DESC LIMIT 5";
            }
            $string_result = $this->data_sum->query5($sql);
        } else if ($pageType == "summary") {
            if ($flag == '1') {
                $sql = "SELECT SUM(attack_count) as a,country_name as b,country_code as c FROM country WHERE time_id='" . $timeID . "' GROUP BY b ORDER BY a DESC";
                $string_result = $this->data_sum->query1($sql);
            } else if ($flag == '2') {
                $sql = "SELECT SUM(attack_count) as b, DAY(summary_day_date) as a  FROM summary_day WHERE time_id = " . $timeID . " GROUP BY DAY(summary_day_date) ORDER BY DAY(summary_day_date) ASC";
                $string_result = $this->data_sum->queryDual($sql);
            } else if ($flag == '3') {
                $sql = "SELECT SUM(attack_count) as b, summary_hour as a FROM summary_hour WHERE time_id = " . $timeID . " GROUP BY summary_hour ORDER BY summary_hour ASC";
                $string_result = $this->data_sum->query5($sql);
            } else {
                $sql = "SELECT attack_count as a, port_name as b FROM port GROUP BY port_name ORDER BY attack_count DESC";
                $string_result = $this->data_sum->queryDual($sql);
            }
        }

        echo $string_result;
    }

    function getMonthByYear() {
        $year = $_GET['year'];

        $sqlTime = $this->data_sum->queryMonthByYear($year);
        foreach ($sqlTime as $time) {
            $month[] = $time;
        }

        echo json_encode($month);
    }

}
