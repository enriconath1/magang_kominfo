<?php

class Data extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    

    public function queryDual($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['b'] = $row['b'];
            $row_array['a'] = (int) $row['a'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query untuk queryAttacker5, queryAttacker5New, queryAttacker
     * queryMalware5, queryMalware, queryTime
     */

    public function query1($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query untuk queryLive, queryAttackerNew
     * 
     */

    public function query2($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            $row_array['c'] = $row['c'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query queryTopAttacker
     * 
     */

    public function query3($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array[$row['a']] = $row['b'];
        }
        return json_encode($row_array);
    }

    /*
     * Query untuk queryDaily
     * 
     */

    public function query4($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['c'] * 1000;
            $row_array['b'] = $row['b'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

}
