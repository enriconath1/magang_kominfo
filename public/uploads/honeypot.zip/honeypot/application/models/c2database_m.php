<?php

class C2database_m extends CI_Model
{
	public function __construct()
	{
		parent::__construct();		
	}
        
        public function query($sql)
        {
	    $query = $this->db->query($sql);
            $data;
            foreach ($query->result_array() as $row)
            {
               $data = $row['a'];
            }
            return $data;
        }
        
        public function queryAB($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array['a'] = $row['a'];
               $row_array['b'] = $row['b'];
               array_push($arr,$row_array);
            }
            return json_encode($arr);
        }
        
        public function queryABC($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array['a'] = $row['a'];
               $row_array['b'] = $row['b'];
               $row_array['c'] = $row['c'];
               array_push($arr,$row_array);
            }
            return json_encode($arr);
        }
        
        public function queryAB2($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array['a'] = $row['c']*1000;
               $row_array['b'] = $row['b'];
               array_push($arr,$row_array);
            }
            return json_encode($arr);
        }
        
        public function queryDual($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array['b'] = $row['b'];
               $row_array['a'] = (int)$row['a'];
               array_push($arr,$row_array);
            }
            return json_encode($arr);
        }
        
        public function queryMap($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array[$row['a']] = $row['b'];
            }
            return json_encode($row_array);
        }
        
        public function queryABCD($sql)
        {
	    $query = $this->db->query($sql);
            $arr = array();
            foreach ($query->result_array() as $row)
            {
               $row_array['a'] = $row['a'];
               $row_array['b'] = $row['b'];
               $row_array['c'] = $row['c'];
               $row_array['d'] = $row['d'];
               array_push($arr,$row_array);
            }
            return json_encode($arr);
        }
}