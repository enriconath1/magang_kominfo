<?php

class Data_sum extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function queryTime($month, $year) {
        $sql = "SELECT time_id FROM time WHERE time_month='" . $month . "' AND time_year='" . $year . "' ";
        $query = $this->db->query($sql);
        $data = array();
        foreach ($query->result_array() as $row) {
            $data[] = $row['time_id'];
        }
        return $data;
    }
    
    public function queryMonthByYear($year) {
        $sql = "SELECT time_month FROM time WHERE time_year='" . $year . "' ";
        $query = $this->db->query($sql);
        $data = array();
        foreach ($query->result_array() as $row) {
            $data[] = $row['time_month'];
        }
        return $data;
    }
    
    public function queryTimeAll() {
        $sql = "SELECT DISTINCT(time_year) FROM time";
        $query = $this->db->query($sql);
        $data = array();
        foreach ($query->result_array() as $row) {
            $data[] = $row['time_year'];
        }
        return $data;
    }

    public function query($sql) {
        $query = $this->db->query($sql);
        $data;
        foreach ($query->result_array() as $row) {
            $data = $row['a'];
        }
        return $data;
    }

    public function queryDual($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['b'] = $row['b'];
            $row_array['a'] = (int) $row['a'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query untuk queryAttacker5, queryAttacker5New, queryAttacker
     * 
     */

    public function query1($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            $row_array['c'] = $row['c'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query untuk queryLive, queryAttackerNew
     * 
     */

    public function query2($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            $row_array['c'] = $row['c'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }

    /*
     * Query queryTopAttacker
     * 
     */

    public function query3($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array[$row['b']] = $row['a'];
        }
        return json_encode($row_array);
    }

    /*
     * Query untuk queryDaily
     * 
     */

    public function query4($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }
    
    /*
     * 
     * queryMalware5, queryMalware, queryTime
     */

    public function query5($sql) {
        $query = $this->db->query($sql);
        $arr = array();
        foreach ($query->result_array() as $row) {
            $row_array['a'] = $row['a'];
            $row_array['b'] = $row['b'];
            array_push($arr, $row_array);
        }
        return json_encode($arr);
    }
    
    

}
