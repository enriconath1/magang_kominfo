$(function() {

    /** 
     * =============================
     * Configurator
     * =============================
     * **/

    $('#configurator .control').click(function(e) {
        e.preventDefault();
        if ($('#configurator').hasClass('active')) {
            $('#configurator').removeClass('active').animate({'left': -255}, 500);
        } else {
            $('#configurator').addClass('active').animate({'left': -1}, 500);
        }
    });



    var url = window.location.href;
    var curUrl = url.replace(url.substr(url.lastIndexOf('/') + 50), '');
    $('ul.nav li a[href="' + curUrl + '"]').parent().addClass('active');

    var pathArray = window.location.href.split('/');
    var protocol = pathArray[0];
    var host = pathArray[2];
    var baseurl = protocol + '//' + host + '/honeypot/';
    var year = $('.year-filter option:selected').val();

    getMonthFilter(baseurl, year);

    $(document).on('click', '#submit-filter', function() {
        var pageType = $('.page-type').val();
        var year = $('.year-filter option:selected').val();
        var month = $('.month-filter option:selected').val();

        if (pageType == "maps") {
            filteringMaps5(baseurl, year, month, pageType);
            filteringMapsAll(baseurl, year, month, pageType);
        } else if (pageType == "ports") {
            filteringPortsAll(baseurl, year, month, pageType)
        } else if (pageType == "malware") {
            filteringMalwareAll(baseurl, year, month, pageType);
            filteringMalware5(baseurl, year, month, pageType);
        } else if (pageType == "summary") {
            filteringSummary(baseurl, year, month, pageType);
            filteringSummaryAttack(baseurl, year, month, pageType);
            filteringSummaryAttackPerHour(baseurl, year, month, pageType);
            filteringSummaryPort(baseurl, year, month, pageType);
        }

    });

    $(document).on('change', '.year-filter', function() {
        year = $('.year-filter option:selected').val();
        getMonthFilter(baseurl, year);
    });



});

function filteringMaps5(baseurl, year, month, pageType) {


    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#topAttacker").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#piechartCountry").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#map").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#sumAtt").find('tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '2', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {

            $("#sumAtt").find('tbody').html('');
            $("#piechartCountry").html('');
            $("#map").html('');
            redrawChart(msg);
			$('legend > span').html('(' + month + ' ' + year + ')');
            


        }});
}

function filteringMapsAll(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#topAttacker").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#piechartCountry").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#map").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#sumAtt").find('tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '1', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {
            redrawMap(msg);
            redrawAttackerByCountry(msg);
			$('legend > span').html('(' + month + ' ' + year + ')');
        }});
}

function filteringPortsAll(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#portCharts").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $('#topPort > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '1', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {
            redrawPiebar(msg);
            redrawListOfAttackedPorts(msg);
            $('legend > span').html('(' + month + ' ' + year + ')');
        }});
}

function filteringMalwareAll(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#malwareChart").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $('#topMalware > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '1', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {
            redrawTopMalware(msg)
            $('legend > span').html('(' + month + ' ' + year + ')');
        }});
}

function filteringMalware5(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#malwareChart").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $('#topMalware > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '2', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {
            redrawMalwareChart(msg);
            $('legend > span').html('(' + month + ' ' + year + ')');
        }});
}

function filteringSummary(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#dailyAttack").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $('#sumAtt > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '2', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {

            $("#dailyAttack").html('');
            redrawAttacksPerDay(msg);
            $('legend > span').html('(' + month + ' ' + year + ')');

        }});
}

function filteringSummaryPort(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $('#topPort > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '4', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {

            $('#topPort > tbody').html('');
            redrawListOfAttackedPorts(msg)
            $('legend > span').html('(' + month + ' ' + year + ')');

        }});
}

function filteringSummaryAttack(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#sumAtt").find('tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '1', pageType: pageType},
        cache: false,
        error: function(response) {
        },
        success: function(msg) {
            $('#sumAtt > tbody').html('');

            redrawAttackerByCountry(msg);
        }});
}

function filteringSummaryAttackPerHour(baseurl, year, month, pageType) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getDataByTime",
        beforeSend: function() {
            $("#hour").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $('#topPort > tbody').html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        data: {year: year, month: month, all: '3', pageType: pageType},
        cache: false,
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {

            $("#hour").html('');
            redrawAttacksPerHour(msg);
            $('legend > span').html('(' + month + ' ' + year + ')');

        }});
}


function redrawPiebar(msg) {
    $('#portCharts').html('');
    var piebar = "pie";
    if (piebar == "pie")
    {

        var d1 = [];
        $.each(msg, function(i, data) {

            d1[i] = {label: "Attack on " + data.b, data: Math.floor(data.a)};
        });


        //chartnya
        if ($("#portCharts,#malwareChart").length)
        {
            $.plot($("#portCharts"), d1,
                    {
                        series: {
                            pie: {
                                show: true,
                                radius: 3 / 4,
                                tilt: 0.5
                            }
                        },
                        grid: {
                            hoverable: true,
                            clickable: true
                        },
                        legend: {
                            show: true
                        }
                    });


            function pieHover(event, pos, obj)
            {
                if (!obj)
                    return;
                percent = parseFloat(obj.series.percent).toFixed(2);
                $("#portHover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
            }
            $("#portCharts").bind("plothover", pieHover);
        }

    }
    else
    {
        var d1 = [];
        var d2 = [];
        $.each(msg, function(i, data) {
            d1[i] = [i, data.a];
            d2[i] = [i, data.b];

        });
        var options = {
            series: {stack: 0,
                lines: {show: false, steps: false},
                bars: {show: true, barWidth: 0.9, align: 'center', }, },
            xaxis: {ticks: d2}
        };

        $.plot($("#portCharts"), [d1], options);
        $('#portHover').html('');
    }
}

function redrawMalwareChart(msg) {
    $('#malwareChart').html('');
    var d1 = [];
    $.each(msg, function(i, data) {
        if (data.b == "null") {
            data.b = "Unknown";
        }
        d1[i] = {data: [[data.b, Math.floor(data.a)]], label: data.b};
    });


    //chartnya
    if ($("#malwareChart").length)
    {
        $.plot($("#malwareChart"), d1,
                {
                    series: {
                        pie: {
                            show: true,
                            radius: 3 / 4,
                            tilt: 0.5
                        }
                    },
                    grid: {
                        hoverable: true,
                        clickable: true
                    },
                    legend: {
                        show: true
                    }
                });


        function pieHover(event, pos, obj)
        {
            if (!obj)
                return;
            percent = parseFloat(obj.series.percent).toFixed(2);
            $("#malwareHover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
        }
        $("#malwareChart").bind("plothover", pieHover);
    }
}

function redrawListOfAttackedPorts(msg) {
    $('#topPort > tbody').html('');
    var d1 = [];
    $.each(msg, function(i, data) {
        $('#topPort > tbody:last').append('<tr><td>Attack on ' + data.b + '</td><td>' + data.a + '</td></tr>');

    });
}

function redrawTopMalware(msg) {
    $('#topMalware > tbody').html('');
    var d1 = [];
    $.each(msg, function(i, data) {
        if (data.b == "null") {
            data.b = "Unknown";
        }
        $('#topMalware > tbody:last').append('<tr><td>' + data.a + '</td><td>' + data.b + '</td></tr>');
    });
}


function redrawChart(msg) {
    var items = [];
    var d1 = [];

    $.each(msg, function(i, data) {
        items.push("<li><a href='#'><span class='red'>" + data.a + "</span>" + data.b + "</li>");
        d1[i] = {label: data.b, data: Math.floor(data.a)};
    });

    $('#topAttacker').append(items.join(''));

    if ($("#piechartCountry").length)
    {
        $.plot($("#piechartCountry"), d1,
                {
                    series: {
                        pie: {
                            show: true,
                            radius: 3 / 4,
                            tilt: 0.5
                        }
                    },
                    grid: {
                        hoverable: true,
                        clickable: true
                    },
                    legend: {
                        show: true
                    }
                });


        function pieHover(event, pos, obj)
        {
            if (!obj)
                return;
            percent = parseFloat(obj.series.percent).toFixed(2);
            $("#hover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
        }
        $("#piechartCountry").bind("plothover", pieHover);
    }
}

function redrawMap(msg) {
    var array = {};
    $.each(msg, function(i, data) {
        var code = data.c;
        var count = data.a;
        array[code] = count;
    });
    var jsonMAP = JSON.stringify(array);
    var jsonOBJ = JSON.parse(jsonMAP);
    console.log(jsonOBJ);
    jQuery(function() {
        var $ = jQuery;
        $('#map').vectorMap({
            backgroundColor: '#f4f4f4',
            zoomButtons: false,
            zoomOnScroll: false,
            map: 'world_mill_en',
            focusOn: {
                x: 0.5,
                y: 0.5,
                scale: 0.5
            },
            series: {
                regions: [{
                        scale: ['#F6C9C9', '#EB1414'],
                        normalizeFunction: 'polynomial',
                        values: jsonOBJ
                    }]
            },
            onRegionLabelShow: function(e, el, code) {
                el.html(el.html() + ' (Attack Hit - ' + msg[code] + ')');
            }
        });

        var mapObj = $('#map').vectorMap('get', 'mapObject');
        var steps = 280;
//        $('#key').html('');
//        $('#key').append('<div style="float:left;">0 &nbsp;</div>');
//        for (var i = 0; i <= steps; i += 20) {
//            var val = msg['CN'] / steps * i;
//            var color = mapObj.series.regions[0].scale.getValue(val);
//            $('#key').append('<div style="background-color:' + color + ';float:left;border-style:solid;border-width:1px;">&nbsp; &nbsp; &nbsp;</div>');
//        }
//        $('#key').append('<div>&nbsp;' + msg['CN'] + '</div>');
    })
}

function redrawAttackerByCountry(msg) {

    var d1 = [];
    var count = 1;
    $.each(msg, function(i, data) {
        $('#sumAtt > tbody:last').append("<tr><td>" + count + "</td><td><img src='assets/icon/" + data.c + ".png'></img> " + data.b + "</td><td>" + data.a + "</td></tr>");
        count++;
        d1[i] = {label: data.b, data: Math.floor(data.a)};
    });

}

function redrawAttacksPerDay(msg) {
    console.log(msg);
    var options = {
        lines: {show: true, fill: true},
        points: {show: true},
		xaxis: {tickDecimals: 0, tickSize: 1}
        //xaxis: {mode: "time", timeformat: "%d", tickSize: [1, "day"]}
    };
    var d1 = [];
    $.each(msg, function(i, data) {
        d1.push([data.a, data.b]);
    });
    console.log(d1);
    $.plot($("#dailyAttack"), [d1], options);

}

function redrawAttacksPerHour(msg) {
    var options = {
        lines: {show: true, fill: true},
        points: {show: true},
        xaxis: {tickDecimals: 0, tickSize: 1}
    };
    var d1 = [];
    $.each(msg, function(i, data) {
        console.log(data.a)
        d1.push([data.a, data.b]);
    });
    $.plot($("#hour"), [d1], options);

}

function getMonthFilter(baseurl, year) {

    $.ajax({
        type: "GET",
        dataType: "json",
        url: baseurl + "getMonthByYear",
        data: {year: year},
        cache: false,
        beforeSend: function() {
            $('.month-filter').attr('disabled', true);
        },
        error: function(response) {
            console.log(response);
        },
        success: function(msg) {
            $('.month-filter').attr('disabled', false);
            $('.month-filter').html('');
            $.each(msg, function(index, value) {
                $('.month-filter').append('<option value="' + value + '">' + value + '</option>');
            })


        }});
}