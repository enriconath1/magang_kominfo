$(document).ready(function() {
    var pathArray = window.location.href.split('/');
    var protocol = pathArray[0];
    var host = pathArray[2];
    var baseurl = protocol + '//' + host + '/honeypot/';

    // getAction(baseurl, 'uniqueIP');
    // getAction(baseurl, 'downloadMalware');
    //  getAction(baseurl, 'totalSensor');
    getAttacker5(baseurl);
    getMalware5(baseurl);
    getMalware(baseurl);
    getPort5(baseurl);
    getPortName(baseurl);
    getDaily(baseurl);
    getTime(baseurl);
    getTopAttacker(baseurl);
    getDecrement(baseurl);
    //getLive(baseurl);
    //getChart(baseurl);
    getPiebar(baseurl, "pie");
    //getMap(baseurl);


})

function getMap(baseurl) {

    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "getMap",
        data: "",
        cache: false,
        error: function(response) {
            
        },
        success: function(msg) {

            jQuery(function() {
                var $ = jQuery;
                $('#map').vectorMap({
                    backgroundColor: '#f4f4f4',
                    zoomButtons: false,
                    zoomOnScroll: false,
                    map: 'world_mill_en',
                    focusOn: {
                        x: 0.5,
                        y: 0.5,
                        scale: 0.5
                    },
                    series: {
                        regions: [{
                                scale: ['#F6C9C9', '#EB1414'],
                                normalizeFunction: 'polynomial',
                                values: msg
                            }]
                    },
                    onRegionLabelShow: function(e, el, code) {
                        el.html(el.html() + ' (Attack Hit - ' + msg[code] + ')');
                    }
                });

                var mapObj = $('#map').vectorMap('get', 'mapObject');
                var steps = 280;
                $('#key').append('<div style="float:left;">0 &nbsp;</div>');
                for (var i = 0; i <= steps; i += 20) {
                    var val = msg['CN'] / steps * i;
                    var color = mapObj.series.regions[0].scale.getValue(val);
                    $('#key').append('<div style="background-color:' + color + ';float:left;border-style:solid;border-width:1px;">&nbsp; &nbsp; &nbsp;</div>');
                }
                $('#key').append('<div>&nbsp;' + msg['CN'] + '</div>');
            })
        }});
}

function getChart(baseurl, value) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "getChart/" + value,
        data: "",
        cache: false,
        beforeSend: function() {
            $("#topAttacker").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#piechartCountry").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#map").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        success: function(msg) {

            $("#topAttacker").html('');
            $("#piechartCountry").html('');
            $("#map").html('');
            var items = [];
            var d1 = [];
            $.each(msg, function(i, data) {
                items.push("<li><a href='#'><span class='red'>" + data.a + "</span>" + data.b + "</li>");
                d1[i] = {label: data.b, data: Math.floor(data.a)};

                //$("#topAttacker ul").append("<li><a href='#'><span class='red'>"+data.a+"</span>"+data.b+"</li>");
            });
            $('#topAttacker').append(items.join(''));

            //chartnya
            if ($("#piechartCountry").length)
            {
                $.plot($("#piechartCountry"), d1,
                        {
                            series: {
                                pie: {
                                    show: true,
                                    radius: 3 / 4
                                }
                            },
                            grid: {
                                hoverable: true,
                                clickable: true
                            },
                            legend: {
                                show: true
                            }
                        });


                function pieHover(event, pos, obj)
                {
                    if (!obj)
                        return;
                    percent = parseFloat(obj.series.percent).toFixed(2);
                    $("#hover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
                }
                $("#piechartCountry").bind("plothover", pieHover);
            }


        }});
}

function getPiebar(baseurl, piebar) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryPortName5",
        cache: false,
        beforeSend: function() {
            $("#portCharts").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        success: function(msg) {
            $('#portCharts').html('');
            if (piebar == "pie")
            {

                var d1 = [];
                $.each(msg, function(i, data) {

                    d1[i] = {label: "Attack on " + data.b, data: Math.floor(data.a)};
                });


                //chartnya
                if ($("#portCharts").length)
                {
                    $.plot($("#portCharts"), d1,
                            {
                                series: {
                                    pie: {
                                        show: true,
                                        radius: 3 / 4,
                                        tilt:0.5
                                    }
                                },
                                grid: {
                                    hoverable: true,
                                    clickable: true
                                },
                                legend: {
                                    show: true
                                }
                            });


                    function pieHover(event, pos, obj)
                    {
                        if (!obj)
                            return;
                        percent = parseFloat(obj.series.percent).toFixed(2);
                        $("#portHover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
                    }
                    $("#portCharts").bind("plothover", pieHover);
                }

            }
            else
            {
                var d1 = [];
                var d2 = [];
                $.each(msg, function(i, data) {
                    d1[i] = [i, data.a];
                    d2[i] = [i, data.b];

                });
                var options = {
                    series: {stack: 0,
                        lines: {show: false, steps: false},
                        bars: {show: true, barWidth: 0.9, align: 'center', }, },
                    xaxis: {ticks: d2}
                };

                $.plot($("#portCharts"), [d1], options);
                $('#portHover').html('');
            }

        }});
}

function getLive(baseurl) {

    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryLive",
        data: "",
        cache: false,
        success: function(msg) {
            var d1 = [];
            $.each(msg, function(i, data) {

                //var table=document.getElementById("live");
                //var row=table.insertRow(1);
                //var cell1=row.insertCell(0);
                //var cell2=row.insertCell(1);
                //cell1.innerHTML=data.a+' -> Attack from '+data.b+' to port '+data.c;
                //cell2.innerHTML="New";
                $('#live').prepend("<tr><td>" + data.a + ' -> Attack from ' + data.b + ' to port ' + data.c + "</td></tr>");
                $('#live > tbody > tr:first').hide().fadeIn('slow')

                //alert(
                //$timer = Math.floor(Math.random() * 5100) + 2500);

            });
            setTimeout(getLive(), 25000);

        }

    });
}

function getList(baseurl, listcountry) {
    if (listcountry == "lastmonth") {
        listcountry = "-1";
    } else {
        listcountry = "-0";
    }
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "getDecrement/" + listcountry,
        cache: false,
        success: function(msg) {

            //$('#sumAtt').removeAttr( 'style' );
            $('table#sumAtt > tbody:last').empty();
            var count = 1;
            $.each(msg, function(i, data) {
                $('table#sumAtt > tbody:last').append("<tr><td>" + count + "</td><td><img src='assets/icon/" + data.c + ".png'></img> " + data.b + "</td><td>" + data.a + "</td></tr>");
                count++;
            });

        }
    });
}

function getAction(baseurl, data) {
    $.ajax({
        type: "GET",
        url: baseurl + "action",
        data: "action=" + data + "",
        cache: false,
        beforeSend: function() {
            $("#" + data + "").html('<center><img src="img/ajax-loader-1.gif" /></center>');
        },
        success: function(msg) {
            $("#" + data + "").html('');
            $("#" + data + "").html(msg);
        }});
}

function getAttacker5(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "getTopFiveAttacker",
        data: "",
        cache: false,
        beforeSend: function() {
            $("#topAttacker").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#piechartCountry").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
            $("#map").html('<center><img src="assets/img/ajax-loader-1.gif" /></center>');
        },
        error: function(e) {
        },
        success: function(msg) {

            $("#topAttacker").html('');
            $("#piechartCountry").html('');
            $("#map").html('');
            var items = [];
            var d1 = [];
            $.each(msg, function(i, data) {
                items.push("<li><a href='#'><span class='red'>" + data.a + "</span>" + data.b + "</li>");
                d1[i] = {label: data.b, data: Math.floor(data.a)};

                //$("#topAttacker ul").append("<li><a href='#'><span class='red'>"+data.a+"</span>"+data.b+"</li>");
            });
            $('#topAttacker').append(items.join(''));

            //chartnya
            if ($("#piechartCountry").length)
            {
                $.plot($("#piechartCountry"), d1,
                        {
                            series: {
                                pie: {
                                    show: true,
                                    radius: 3 / 4,
                                    tilt: 0.5
                                }
                            },
                            grid: {
                                hoverable: true,
                                clickable: true
                            },
                            legend: {
                                show: true
                            }
                        });


                function pieHover(event, pos, obj)
                {
                    if (!obj)
                        return;
                    percent = parseFloat(obj.series.percent).toFixed(2);
                    $("#hover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
                }
                $("#piechartCountry").bind("plothover", pieHover);
            }


        }});
}

function getMalware5(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryMalware5",
        data: "",
        error: function(response){
            
        },
        cache: false,
        success: function(msg) {
            var d1 = [];
            $.each(msg, function(i, data) {
                if (data.b == "null") {
                    data.b = "Unknown";
                }
                d1[i] = {data: [[data.b, Math.floor(data.a)]], label: data.b};
            });


            //chartnya
            if ($("#malwareChart").length)
            {
                $.plot($("#malwareChart"), d1,
                        {
                            series: {
                                pie: {
                                    show: true,
                                    radius: 3 / 4,
                                    tilt: 0.5
                                }
                            },
                            grid: {
                                hoverable: true,
                                clickable: true
                            },
                            legend: {
                                show: true
                            }
                        });


                function pieHover(event, pos, obj)
                {
                    if (!obj)
                        return;
                    percent = parseFloat(obj.series.percent).toFixed(2);
                    $("#malwareHover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
                }
                $("#malwareChart").bind("plothover", pieHover);
            }



        }});
}

function getMalware(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryMalware",
        data: "",
        cache: false,
        success: function(msg) {
            var d1 = [];
            $.each(msg, function(i, data) {
                if (data.b == "null") {
                    data.b = "Unknown";
                }
                $('#topMalware > tbody:last').append('<tr><td>' + data.a + '</td><td>' + data.b + '</td></tr>');
            });
        }});
}

function getPort5(baseurl) {

    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryPortName5",
        data: "",
        cache: false,
        success: function(msg) {
            var d1 = [];
            $.each(msg, function(i, data) {

                d1[i] = {label: "Attack on " + data.b, data: Math.floor(data.a)};
            });

            if ($("#portChart").length)
            {
                $.plot($("#portChart"), d1,
                        {
                            series: {
                                pie: {
                                    show: true,
                                    radius: 3 / 4,
                                }
                            },
                            grid: {
                                hoverable: true,
                                clickable: true
                            },
                            legend: {
                                show: true
                            },
                        });


                function pieHover(event, pos, obj)
                {
                    if (!obj)
                        return;
                    percent = parseFloat(obj.series.percent).toFixed(2);
                    $("#portHover").html('<span style="font-weight: bold; color: black">' + obj.series.label + ' (' + percent + '%)</span>');
                }
                $("#portChart").bind("plothover", pieHover);
            }

        }});
}


function getPort52(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryPortName5",
        data: "",
        cache: false,
        success: function(msg) {
            var d1 = [];
            var d2 = [];
            $.each(msg, function(i, data) {
                d1[i] = [i, data.a];
                d2[i] = [i, data.b];
            });

            var options = {
                series: {stack: 0,
                    lines: {show: false, steps: false},
                    bars: {show: true, barWidth: 0.9, align: 'center', }, },
                xaxis: {ticks: d2}
            };

            $.plot($("#portCharts"), [d1], options);

        }});
}

function getPortName(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryPortName",
        data: "",
        cache: false,
        success: function(msg) {
            var d1 = [];
            $.each(msg, function(i, data) {
                $('#topPort > tbody:last').append('<tr><td>Attack on ' + data.b + '</td><td>' + data.a + '</td></tr>');

            });
        }});
}

function getDaily(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryDaily",
        data: "",
        error: function(e){
        },
        cache: false,
        success: function(msg) {
            
            var options = {
                lines: {show: true, fill: true},
                points: {show: true},
				xaxis: {tickDecimals: 0, tickSize: 1}
                //xaxis: {mode: "time", timeformat: "%d", tickSize: [1, "day"]}
            };
            var d1 = [];
            $.each(msg, function(i, data) {
                d1.push([data.a, data.b]);
            });
            
            $.plot($("#dailyAttack"), [d1], options);
        }});
}

function getTime(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryTime",
        data: "",
        cache: false,
        success: function(msg) {
            
            var options = {
                lines: {show: true, fill: true},
                points: {show: true},
                xaxis: {tickDecimals: 0, tickSize: 1}
            };
            var d1 = [];
            $.each(msg, function(i, data) {
                d1.push([data.a, data.b]);
            });
            $.plot($("#hour"), [d1], options);

        }});
}

function getTopAttacker(baseurl) {
    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "statistic_controller/queryTopAttacker",
        data: "",
        cache: false,
        success: function(msg) {
            
            jQuery(function() {

                var $ = jQuery;
                $('#map').vectorMap({
                    backgroundColor: '#f4f4f4',
                    zoomButtons: false,
                    zoomOnScroll: false,
                    map: 'world_mill_en',
                    focusOn: {
                        x: 0.5,
                        y: 0.5,
                        scale: 0.5
                    },
                    series: {
                        regions: [{
                                scale: ['#F6C9C9', '#EB1414'],
                                normalizeFunction: 'polynomial',
                                values: msg
                            }]
                    },
                    onRegionLabelShow: function(e, el, code) {
                        el.html(el.html() + ' (Attack Hit - ' + msg[code] + ')');
                    }
                });

//                var mapObj = $('#map').vectorMap('get', 'mapObject');
//                var steps = 280;
//                $('#key').append('<div style="float:left;">0 &nbsp;</div>');
//                for (var i = 0; i <= steps; i += 20) {
//                    var val = msg['CN'] / steps * i;
//                    var color = mapObj.series.regions[0].scale.getValue(val);
//                    $('#key').append('<div style="background-color:' + color + ';float:left;border-style:solid;border-width:1px;">&nbsp; &nbsp; &nbsp;</div>');
//                }
//                $('#key').append('<div>&nbsp;' + msg['CN'] + '</div>');
            })
        }});
}

function getDecrement(baseurl) {

    $.ajax({
        type: "GET",
        dataType: 'json',
        url: baseurl + "getAttackerByCountry",
        data: "",
        cache: false,
        success: function(msg) {
            
            var d1 = [];
            var count = 1;
            $.each(msg, function(i, data) {
                $('#sumAtt > tbody:last').append("<tr><td>" + count + "</td><td><img src='assets/icon/" + data.c + ".png'></img> " + data.b + "</td><td>" + data.a + "</td></tr>");
                count++;
                d1[i] = {label: data.b, data: Math.floor(data.a)};
            });
        }});

}

